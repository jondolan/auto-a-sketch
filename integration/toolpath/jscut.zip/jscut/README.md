jscut
=====

A simple CAM package that runs in the browser. Very new, very alpha.

Live version at http://jscut.org/jscut.html

The master branch tends to be stale; the gh-pages branch is current, including bug fixes. The live version pulls from gh-pages.
